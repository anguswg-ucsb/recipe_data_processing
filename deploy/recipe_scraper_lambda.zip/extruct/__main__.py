from __future__ import print_function
from extruct.tool import main


if __name__ == '__main__':
    print(main())
